package com.cg.Project.Service;


import java.util.List;

import com.cg.Project.Bean.Candidate;
import com.cg.Project.Bean.CandidatePersonal;
import com.cg.Project.Bean.CandidateQualifications;
import com.cg.Project.Bean.CandidateWorkHistory;
import com.cg.Project.Bean.JobApplied;
import com.cg.Project.Bean.JobRequirements;




public interface CandidateService {
		
		public String addResumep(CandidatePersonal p)  ;
		public String addResumeq(CandidateQualifications q)  ;
		public String addResumew(CandidateWorkHistory w)  ;
			List<JobRequirements> getJobRequirements() ;

			
					

			int applyForJob(JobApplied job);

			//ArrayList<JobRequirements> findBy(String qualificationRequired,
					//String positionRequired, int experienceRequired,
				//	String jobLocation);

			String modifyResume(Candidate candidate, String candidateId);
			public String modifyResumep(CandidatePersonal e, String candidateId);
			public String modifyResumeq(CandidateQualifications e,
					String candidateId);
			public String modifyResumew(CandidateWorkHistory e,
					String candidateId);

}
