package com.cg.Project.Dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.Project.Bean.JobRequirements;




public interface JobRequirementsDao extends JpaRepository<JobRequirements, String>{
	

}
