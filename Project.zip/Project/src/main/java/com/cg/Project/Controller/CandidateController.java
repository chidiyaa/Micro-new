package com.cg.Project.Controller;


import java.util.List;









import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.Project.Bean.Candidate;
import com.cg.Project.Bean.CandidatePersonal;
import com.cg.Project.Bean.CandidateQualifications;
import com.cg.Project.Bean.CandidateWorkHistory;
import com.cg.Project.Bean.JobApplied;
import com.cg.Project.Bean.JobRequirements;
import com.cg.Project.Service.CandidateService;



@RestController
@RequestMapping("/candidate")
public class CandidateController {
	@Autowired
	CandidateService service;
	/*@GetMapping("/find/{qual}/{pos}/{exp}/{loc}")
	public ArrayList<JobRequirements> find(@PathVariable("qual") String qualification,
			@PathVariable("pos") String position,@PathVariable("exp")  int experience,@PathVariable("loc") String location)
	{
		return service.findBy(qualification,position, experience,location);
	}*/
	@PostMapping("/insertp")
	public String insert(@RequestBody CandidatePersonal p)
	{//Candidate c = new Candidate(p,q,w);
		String s=service.addResumep(p);
		
		return s;
	}
	@PostMapping("/insertq")
	public String insert(@RequestBody CandidateQualifications q)
	{//Candidate c = new Candidate(p,q,w);
		String s=service.addResumeq(q);
		
		return s;
	}
	@PostMapping("/insertw")
	public String insert(@RequestBody CandidateWorkHistory w)
	{//Candidate c = new Candidate(p,q,w);
		String s=service.addResumew(w);
		
		return s;
	}
	@PostMapping("/modifyp/{cId}")
	public String modify(@PathVariable("cId") String candidateId,@RequestBody CandidatePersonal e)
	{String s=service.modifyResumep(e,candidateId);
		
		return s;
	}
	@PostMapping("/modifyq/{cId}")
	public String modify(@PathVariable("cId") String candidateId,@RequestBody CandidateQualifications e)
	{String s=service.modifyResumeq(e,candidateId);
		
		return s;
	}
	@PostMapping("/modifyw/{cId}")
	public String modify(@PathVariable("cId") String candidateId,@RequestBody CandidateWorkHistory e)
	{String s=service.modifyResumew(e,candidateId);
		
		return s;
	}
	@PostMapping("/apply")
	public String insert(@RequestBody JobApplied e)
	{
		service.applyForJob(e);
		return "SUCCESS";
	}
@GetMapping("/allJob")
public List<JobRequirements> getJobRequirements(){
	return service.getJobRequirements();
	
	
}
}
